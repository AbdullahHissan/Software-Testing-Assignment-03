package org.example;

public class OrderService {
    public boolean placeOrder(int total) {
        return Boolean.parseBoolean("Order of $" + total + " has been placed successfully!");
    }
}