package org.example;

public class DiscountService {
    public int applyDiscount(int total) {
        // For simplicity, apply 10% discount
        return (int)(total * 0.9);
    }
}