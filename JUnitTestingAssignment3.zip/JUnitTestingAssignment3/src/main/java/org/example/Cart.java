package org.example;

import org.apache.commons.math3.stat.descriptive.summary.Product;

import java.util.ArrayList;
import java.util.List;

public class Cart {
    private final List<Product> products = new ArrayList<>();

    // Add product by passing a Product object
    public void addProduct(Product product) {
        products.add(product);
    }

    // Add a default sample product (no arguments)
    public void addProduct() {
        products.add(new Product()); // default price 100, name "Apple"
    }

    // Calculate total price of all products in the cart
    public int getTotal() {
        int total = 0;
        for (Product p : products) total += p.getN(); // use getPrice() from your Product class
        return total;
    }

}