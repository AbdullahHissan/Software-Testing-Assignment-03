package org.example;

public class Main {
    public static void main(String[] args) {

        Cart cart = new Cart();
        cart.addProduct();
        cart.addProduct();

        int total = cart.getTotal();

        DiscountService discount = new DiscountService();
        total = discount.applyDiscount(total);

        PaymentService payment = new PaymentService();

        if (payment.pay(total)) {
            OrderService order = new OrderService();
            System.out.println("Order placed: " + order.placeOrder(total));
        }
    }
}