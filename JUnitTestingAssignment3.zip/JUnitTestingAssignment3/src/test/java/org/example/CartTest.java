package org.example;

import org.apache.commons.math3.stat.descriptive.summary.Product;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class CartTest {

    @Test
    void should_returnZero_when_cartIsEmpty() {
        Cart cart = new Cart();
        assertEquals(0, cart.getTotal());
    }

    @Test
    void should_addSingleProduct_when_productAdded() {
        Cart cart = new Cart();
        cart.addProduct(new Product());
        assertEquals(500, cart.getTotal());
    }

    @Test
    void should_addMultipleProducts_when_multipleAdded() {
        Cart cart = new Cart();
        cart.addProduct(new Product());
        cart.addProduct(new Product());
        assertEquals(500, cart.getTotal()); // total = 200 + 300 = 500
    }

    @Test
    public void should_handleZeroPrice_when_productPriceZero() {
        Cart cart = new Cart();
        cart.addProduct(new Product());
        assertEquals(0, cart.getTotal());
    }

    @Test
    void should_handleNegativePrice_when_productPriceNegative() {
        Cart cart = new Cart();
        assertThrows(IllegalArgumentException.class, () ->
                cart.addProduct(new Product())
        );
    }

    @Test
    void should_updateTotalCorrectly_when_productsAddedSequentially() {
        Cart cart = new Cart();
        cart.addProduct(new Product());
        cart.addProduct(new Product());
        assertEquals(300, cart.getTotal());
    }

    @Test
    void should_returnCorrectTotal_when_largeValuesUsed() {
        Cart cart = new Cart();
        cart.addProduct(new Product());
        assertEquals(10000, cart.getTotal());
    }

    @Test
    void should_notCrash_when_noProductsAdded() {
        Cart cart = new Cart();
        assertDoesNotThrow(cart::getTotal);
    }
}