package org.example;

import org.apache.commons.math3.stat.descriptive.summary.Product;
import org.junit.jupiter.api.*;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

import static org.junit.jupiter.api.Assertions.*;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
@Tag("fast")
public class FastCartTest {

    private Cart cart;

    @BeforeEach
    void setup() {
        cart = new Cart();
    }


    @org.junit.Test
    @Order(1)
    public void testEmptyCart() {
        assertEquals(0, cart.getTotal());
    }

    @Order(3)
    @ParameterizedTest
    @ValueSource(ints = {10, 20, 30, 40, 50})
    void testAddMultiplePrices(int price) {
        Cart c = new Cart();
        c.addProduct(new Product());
        assertEquals(price, c.getTotal());
    }

}