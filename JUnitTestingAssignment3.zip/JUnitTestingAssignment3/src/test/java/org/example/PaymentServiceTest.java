package org.example;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PaymentServiceTest {

    @Test
    void should_returnTrue_when_amountPositive() {
        PaymentService p = new PaymentService();
        assertTrue(p.pay(100));
    }

    @Test
    void should_returnFalse_when_amountZero() {
        PaymentService p = new PaymentService();
        assertFalse(p.pay(0));
    }

    @Test
    void should_returnFalse_when_amountNegative() {
        PaymentService p = new PaymentService();
        assertFalse(p.pay(-50));
    }

    @Test
    void should_handleLargeAmount_when_amountHigh() {
        PaymentService p = new PaymentService();
        assertTrue(p.pay(10000));
    }

    @Test
    void should_notCrash_when_calledMultipleTimes() {
        PaymentService p = new PaymentService();
        assertDoesNotThrow(() -> p.pay(100));
    }

    @Test
    void should_validateBoundary_when_amountOne() {
        PaymentService p = new PaymentService();
        assertTrue(p.pay(1));
    }

    @Test
    void should_returnFalse_when_amountIsMinimum() {
        PaymentService p = new PaymentService();
        assertFalse(p.pay(0));
    }

    @Test
    void should_returnTrue_when_validAmountUsed() {
        PaymentService p = new PaymentService();
        assertTrue(p.pay(500));
    }
}