package org.example;

import org.apache.commons.math3.stat.descriptive.summary.Product;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvFileSource;
import static org.junit.jupiter.api.Assertions.*;

public class Test {

    private Cart cart;

    @BeforeEach
    void setup() {
        cart = new Cart();
    }

    @ParameterizedTest
    @CsvFileSource(resources = "/cartTests.csv", numLinesToSkip = 1)
    void testFromCSV(String category, String priceStr, String expectedStr) {
        int price = parsePrice(priceStr);
        int expected = parseExpected(expectedStr);

        if (category.equals("Invalid") || price < 0) {
            assertThrows(Exception.class, () -> cart.addProduct(new Product()));
        } else {
            cart.addProduct(new Product());
            assertEquals(expected, cart.getTotal());
        }
    }

    private int parsePrice(String str) {
        try { return Integer.parseInt(str); }
        catch (NumberFormatException e) { return -1; }
    }

    private int parseExpected(String str) {
        try { return Integer.parseInt(str); }
        catch (NumberFormatException e) { return 0; }
    }
}