package org.example;

import org.apache.poi.ss.usermodel.*;
import org.junit.jupiter.api.BeforeEach;

public class CartExcelTest {

    public static final String EXCEL_PATH;
    public static Cell cell;

    static {
        EXCEL_PATH = "/cartData.xlsx";
    }

    @BeforeEach
    void setup() {
    }

    public static String getCellAsString(Cell cell) {
        CartExcelTest.cell = cell;
        if (cell == null) return "";
        return cell.getCellType() == CellType.STRING ? cell.getStringCellValue() : "";
    }

    public static int getCellAsInt(Cell cell) {
        if (cell == null) return 0;
        if (cell.getCellType() == CellType.NUMERIC) return (int) cell.getNumericCellValue();
        try { return Integer.parseInt(cell.getStringCellValue().trim()); }
        catch (Exception e) { return -1; }
    }

}