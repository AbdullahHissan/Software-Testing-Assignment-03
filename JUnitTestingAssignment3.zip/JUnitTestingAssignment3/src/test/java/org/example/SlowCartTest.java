package org.example;

import org.apache.commons.math3.stat.descriptive.summary.Product;
import org.junit.jupiter.api.*;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

import static org.junit.jupiter.api.Assertions.assertEquals;

@Tag("slow")
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class SlowCartTest {

    private Cart cart;

    @BeforeEach
    void setup() {
        cart = new Cart();
    }

    @Order(1)
    @ParameterizedTest
    @CsvSource({"1000, 1000", "5000, 5000", "10000, 10000", "50000, 50000", "100000, 100000"})
    void testLargeValues(int expected) {
        cart.addProduct(new Product()); // FIXED
        assertEquals(expected, cart.getTotal());
    }

    @Order(2)
    @ParameterizedTest
    @CsvSource({"10, 10", "20, 20", "30, 30", "40, 40", "50, 50"}) // FIXED
    void testSequentialAdds(int expected) {
        cart.addProduct(new Product()); // FIXED
        assertEquals(expected, cart.getTotal());
    }

}