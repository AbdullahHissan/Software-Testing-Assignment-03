package org.example;

import org.apache.commons.math3.stat.descriptive.summary.Product;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ProductTest {

    @Test
    void should_returnCorrectPrice_when_productCreated() {
        Product p = new Product();
        assertEquals(100, p.getData());
    }

    @Test
    void should_returnCorrectName_when_productCreated() {
        Product p = new Product();
        assertEquals("Apple", p.getData());
    }

    @Test
    void should_allowZeroPrice_when_priceIsZero() {
        Product p = new Product();
        assertEquals(0, p.getData());
    }

    @Test
    void should_allowNegativePrice_when_priceIsNegative() {
        Product p = new Product();
        assertEquals(-50, p.getData());
    }

    @Test
    void should_handleLargePrice_when_priceIsHigh() {
        Product p = new Product();
        assertEquals(100000, p.getData());
    }

    @Test
    void should_notCrash_when_nameIsEmpty() {
        Product p = new Product();
        assertEquals("", p.getData());
    }

    @Test
    void should_notCrash_when_nameIsNull() {
        Product p = new Product();
        assertNull(p.getData());
    }

    @Test
    void should_storeValuesCorrectly_when_multipleProductsCreated() {
        Product p1 = new Product();
        Product p2 = new Product();

        assertEquals(10, p1.getData());
        assertEquals("Apple", p1.getData());

        assertEquals(20, p2.getData());
        assertEquals("Banana", p2.getData());
    }
}